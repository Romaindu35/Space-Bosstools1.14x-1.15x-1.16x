package net.mcreator.boss_tools.procedures;

import net.mcreator.boss_tools.BossToolsModElements;

import java.util.Map;

@BossToolsModElements.ModElement.Tag
public class MoonPortalTriggerUsedProcedure extends BossToolsModElements.ModElement {
	public MoonPortalTriggerUsedProcedure(BossToolsModElements instance) {
		super(instance, 76);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
	}
}
