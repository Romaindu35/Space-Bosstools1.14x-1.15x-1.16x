package net.mcreator.boss_tools.procedures;

import net.mcreator.boss_tools.BossToolsModElements;

import java.util.Map;

@BossToolsModElements.ModElement.Tag
public class RocketRightClickedOnEntityProcedure extends BossToolsModElements.ModElement {
	public RocketRightClickedOnEntityProcedure(BossToolsModElements instance) {
		super(instance, 72);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
	}
}
