package net.mcreator.boss_tools.procedures;

import net.mcreator.boss_tools.BossToolsModElements;

import java.util.Map;

@BossToolsModElements.ModElement.Tag
public class RocketpotionOnPotionActiveTickProcedure extends BossToolsModElements.ModElement {
	public RocketpotionOnPotionActiveTickProcedure(BossToolsModElements instance) {
		super(instance, 103);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
	}
}
