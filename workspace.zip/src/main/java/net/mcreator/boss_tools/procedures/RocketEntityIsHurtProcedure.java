package net.mcreator.boss_tools.procedures;

import net.mcreator.boss_tools.BossToolsModElements;

import java.util.Map;

@BossToolsModElements.ModElement.Tag
public class RocketEntityIsHurtProcedure extends BossToolsModElements.ModElement {
	public RocketEntityIsHurtProcedure(BossToolsModElements instance) {
		super(instance, 73);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
	}
}
