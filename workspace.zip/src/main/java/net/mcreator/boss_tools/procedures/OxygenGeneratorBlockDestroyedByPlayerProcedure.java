package net.mcreator.boss_tools.procedures;

import net.mcreator.boss_tools.BossToolsModElements;

import java.util.Map;

@BossToolsModElements.ModElement.Tag
public class OxygenGeneratorBlockDestroyedByPlayerProcedure extends BossToolsModElements.ModElement {
	public OxygenGeneratorBlockDestroyedByPlayerProcedure(BossToolsModElements instance) {
		super(instance, 196);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
	}
}
